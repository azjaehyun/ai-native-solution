# **LLM 애플리케이션 보안 점검 가이드**

## **1. 모델 점검**

### **주요 점검 항목**

#### **1.1 프롬프트 인젝션**
- **위협 시나리오**: 악의적인 입력으로 모델이 비정상적인 동작을 수행하거나 민감 정보를 노출하는 상황.
- **대응 방안**:
  - 사용자 입력과 시스템 프롬프트를 철저히 분리.
  - 입력 문자열의 구조적 검증(예: 금지된 키워드 탐지).
  - 역할 기반 프롬프트 설정:
    ```python
    SYSTEM_PROMPT = "You are a helpful assistant. Only answer queries based on the provided context."
    user_input = sanitize_input(input("User: "))
    prompt = f"{SYSTEM_PROMPT}\nUser: {user_input}"
    response = model.generate(prompt)
    ```

#### **1.2 민감 정보 노출**
- **위협 시나리오**: 모델이 학습 데이터에 포함된 민감 정보를 응답에서 노출.
- **대응 방안**:
  - 민감 정보 필터링:
    ```python
    def filter_sensitive_output(output):
        sensitive_patterns = [
            r'\b\d{6}-\d{7}\b',       # 주민등록번호
            r'\b(?:\d{3}-\d{2}-\d{4})\b',  # 미국 SSN 형식
            r'\b[\w\.-]+@[\w\.-]+\.\w+\b', # 이메일 주소
            r'\b(?:\d{3}-\d{3}-\d{4})\b'  # 전화번호
        ]
        for pattern in sensitive_patterns:
            if re.search(pattern, output):
                return "Sensitive information detected. Response filtered."
        return output
    ```
  - 학습 데이터 검증 도구 활용(OpenAI, Hugging Face 등).

#### **1.3 모델 내부 악성 페이로드**
- **위협 시나리오**: 학습 데이터나 템플릿에 악성 코드 삽입.
- **대응 방안**:
  - 학습 데이터 정적 분석:
    ```bash
    grep -r "<script>" ./training_data/
    ```
  - 신뢰할 수 있는 데이터 소스만 사용.

#### **1.4 학습 데이터 오염**
- **위협 시나리오**: 공격자가 학습 데이터에 편향 또는 백도어 데이터를 삽입하여 모델의 출력을 왜곡.
- **대응 방안**:
  - 데이터 수집 및 전처리 자동화:
    ```python
    import pandas as pd

    def clean_data(df):
        df = df.dropna()
        df = df[~df['text'].str.contains("malicious_pattern")]
        return df

    cleaned_data = clean_data(raw_data)
    ```

---

## **2. LLM 통합 점검**

### **주요 점검 항목**

#### **2.1 클라이언트 내 프롬프트 생성**
- **위협 시나리오**: 클라이언트에서 생성된 프롬프트가 취약성을 유발.
- **대응 방안**:
  - 프롬프트 구조 표준화 및 검증:
    ```python
    ALLOWED_ACTIONS = ["search", "summarize", "translate"]

    def validate_action(action):
        if action not in ALLOWED_ACTIONS:
            raise ValueError("Invalid action")

    validate_action(user_action)
    ```

#### **2.2 오류 메시지 출력**
- **위협 시나리오**: 오류 메시지에 민감한 시스템 정보 노출.
- **대응 방안**:
  - 사용자 대상 메시지 제한:
    ```python
    try:
        process_request()
    except Exception as e:
        log_error(e)  # 내부 로그에만 기록
        print("An error occurred. Please try again later.")
    ```

#### **2.3 취약한 서드파티 소프트웨어 사용**
- **위협 시나리오**: 외부 라이브러리에서 발생하는 취약점 악용.
- **대응 방안**:
  - 정기적인 보안 업데이트 및 서드파티 감사 수행.
  - 신뢰할 수 있는 저장소에서 라이브러리 설치:
    ```bash
    pip install --index-url=https://secure.pypi.org/ <library>
    ```

#### **2.4 RAG 데이터 오염**
- **위협 시나리오**: 악성 데이터를 벡터 DB에 삽입하여 모델 동작 왜곡.
- **대응 방안**:
  - 벡터 DB 입력 검증:
    ```python
    def validate_vector_data(data):
        if contains_malicious_content(data):
            raise ValueError("Malicious content detected")

    validate_vector_data(new_entry)
    ```

---

## **3. 에이전트 점검**

### **주요 점검 항목**

#### **3.1 API 매개 변수 변조**
- **위협 시나리오**: API 요청 파라미터가 악의적으로 변조.
- **대응 방안**:
  - 파라미터 유효성 검사:
    ```python
    def validate_params(params):
        if "dangerous_param" in params:
            raise ValueError("Invalid parameter")

    validate_params(api_request_params)
    ```

#### **3.2 부적절한 권한 사용**
- **위협 시나리오**: 권한 초과로 비인가된 작업 수행.
- **대응 방안**:
  - 권한 기반 액세스 제어:
    ```python
    def check_user_permissions(user, action):
        if action not in user.allowed_actions:
            raise PermissionError("Unauthorized action")

    check_user_permissions(current_user, requested_action)
    ```

#### **3.3 사용자 동의 절차 누락**
- **위협 시나리오**: 민감한 작업 수행 시 사용자 확인 절차 미비.
- **대응 방안**:
  - 사용자 동의 인터페이스 구현:
    ```python
    def request_user_consent():
        consent = input("Do you approve this action? (yes/no)")
        if consent.lower() != "yes":
            raise PermissionError("Action not approved")

    request_user_consent()
    ```

#### **3.4 샌드박스 미적용**
- **위협 시나리오**: 코드 실행 환경 격리가 이루어지지 않아 시스템이 손상.
- **대응 방안**:
  - 격리된 환경에서 코드 실행:
    ```bash
    docker run --rm -v $(pwd):/sandbox -w /sandbox sandbox-image python script.py
    ```

---

## **4. 위험도 평가 및 대응 전략**

### **위험도 분류 및 대응**

| 위험도 | 주요 항목                                    | 대응 전략                                   |
|--------|-----------------------------------------|-----------------------------------------|
| 상     | 프롬프트 인젝션, 서드파티 취약점                 | 침투 테스트, 입력 검증 강화, 최신 보안 패치 적용      |
| 중     | RAG 데이터 오염, API 매개 변수 변조           | 데이터 검증 프로세스, 실시간 모니터링                |
| 하     | 사용자 동의 절차 누락, 오류 메시지 출력           | 절차 도입, 디버깅 정보 제한                        |

### **종합 대응 방안**
1. **침투 테스트**: 정기적으로 모의 해킹을 수행하여 시스템의 취약점을 사전에 탐지.
2. **모니터링 및 이상 탐지**: 실시간 로그 분석 및 이상 행동 패턴 탐지 도구 활용.
3. **보안 정책 수립**: LLM 운영 환경에 특화된 정책을 문서화하고 정기적으로 갱신.

---

이 문서는 LLM 애플리케이션의 주요 보안 점검 항목 및 구체적인 대안 방안을 포함하여 작성되었습니다. 각 항목별로 위험도를 평가하고 적합한 보안 솔루션을 적용하여 안전한 시스템 운영을 목표로 합니다.

